package org.example;
import java.util.Scanner;
/* I saw you making comments in this program with these asterisk comment things
* I thought I would try it out for myself, and it's actually way nicer than having to
* start every line with // manually- I'll try this next time :) */
public class Main {
    public static void main(String[] args) {
        final double STATE_TAX_RATE = 0.04;
        final double COUNTY_TAX_RATE = 0.02;
        // Same tax rates!
        double purchasePrice = inputPurchasePrice();
        // Using a Scanner variable like last time...
        double stateTax = calculateTax(purchasePrice, STATE_TAX_RATE);
        double countyTax = calculateTax(purchasePrice, COUNTY_TAX_RATE);
        double totalTax = stateTax + countyTax;
        // I initially wanted to combine both tax statements like this:
        // totalTax = (calculateTax(purchasePrice, STATE_TAX_RATE) + calculateTax(purchasePrice, COUNTY_TAX_RATE))
        // But honestly, since we have stateTax and countyTax already declared with their values
        // You can find the total by just adding them together. Less is more!
        double totalPrice = calculateTotal(purchasePrice,totalTax);
        // Not entirely sure why this one had to be a method, because it just adds two variables together
        // Same thing with calculateTax(), it's just multiplication
        // But I suppose it keeps the Main organized
        displayTotals(purchasePrice, stateTax, countyTax, totalTax, totalPrice);
    }
    public static double inputPurchasePrice() {
        Scanner userInput = new Scanner(System.in);
        System.out.print("Enter the price of the item as a double: ");
        return userInput.nextDouble();
    }
    public static double calculateTax(double purchasePrice, double taxRate) {
        return purchasePrice * taxRate;
    }
    public static double calculateTotal(double purchasePrice, double calcTax) {
        return purchasePrice + calcTax;
    }
    public static void displayTotals(double purchasePrice, double stateTax, double countyTax, double totalTax, double totalPrice) {
        System.out.printf("Purchase Price: $%.2f%n",purchasePrice);
        System.out.printf("State Tax: $%.2f%n",stateTax);
        System.out.printf("County Tax: $%.2f%n",countyTax);
        System.out.printf("Total Tax: $%.2f%n",totalTax);
        System.out.printf("Total Price: $%.2f%n",totalPrice);
        // This is the way I was SUPPOSED to do it the first time
        // Not gunna risk messing with those display boxes again this time
        // Once was enough for me :)
    }
    }