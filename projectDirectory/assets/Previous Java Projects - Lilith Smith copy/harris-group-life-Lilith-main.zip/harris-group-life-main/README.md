# Harris Group Life Project
The Harris Group Life Insurance company computes annual policy premiums based on the retirement
status, residency and age a customer turns in the current calendar year.

**Retirees:** The premium is computed for retirees by taking their age and multiplying by $7.50. For
example, a 72-year-old retiree would pay $540, which is calculated by multiplying 72 by 7.50.

**In-State, Non-Retired:** The premium is computed for non-retiree, in-state residents by taking the decade
of the customer’s age, adding 15 to it and multiplying by 20. For example, a 72-year-old would pay $440,
which is calculated by adding the decades (7) to 15, and then multiplying by 20.

**Out-of-State, Non-Retired:** The premium is computed for non-retiree, out-of-state residents by taking the
decade of the customer’s age, adding 15 to it and multiplying by 22.50. For example, a 72-year-old
would pay $495, which is calculated by adding the decades (7) to 15, and then multiplying by 22.50.

## Project Instructions 

[Follow these general instructions to fork and clone the project](https://ihccjava.github.io/docs/general-project-instructions/)

### Create a class called HarrisGroupLife class

Comments should be at the top of this and all programs and include the program’s purpose,
your name and date.
- Create the main method
- Create input methods for policy holder name, birth year (YYYY), current year (YYYY), in-state
  residency (T/F), and retirement status (Y/N).
- Use the charAt() method to convert the retirement status Y/N from String to char.
- Use an if statement to convert residency input from a String T/F to Boolean.
- Place input data into a LifePolicy object using the parameterized constructor
- After input, calculate the policy cost (use method in the LifePolicy class)
- After calculations, display the current year, policy holder name, age, residency (In-state/Out-ofState), Retirement Status (Retiree/Non-Retiree), and policy cost. Display string will be built in
  the LifePolicy class.

### Create an instantiable class called LifePolicy

- private instance variables for policy holder name, birth year (YYYY), current year (YYYY), instate residency (T/F), and retirement status (Y/N).
- default constructor – Values of your choice
- parameterized constructor for all user entered values
- instance method to calculate the policy cost
- instance method to return the formatted output string. Numeric values must be formatted.
  Residency must print “In-State” or “Out-of-State”. Retirement Status must print “Retiree” or
  “Non-Retiree”.

### Create a test class (in the test src folder) called LifePolicyTests

[Reminder how to setup JUnit tests in your project](https://ihccjavaii.github.io/docs/junit/junit-setup-instructions.html)
- write at least three unit tests (methods with the @Test annotation) to test your calculation method
- Run these tests and make sure they pass!

### Extra credit enhancements (optional)

- Retrieve the current year from the system using the LocalDate class and .now() and .getYear()
methods in the instantiable class. Book reference Pg. 210-215.
- Declare the date variables as class variables (Static)
- No longer request the current date from the user

### Rubric

Projects are graded on functionality (does it compile, can the user do what they are supposed to, and do they get the expected results). It is also graded on features added in the instructions, like including the correct methods, constructors, data conversions, and tests.

| Topic                    | Task                                                                                 | Points |
|--------------------------|--------------------------------------------------------------------------------------|--------|
| **HarrisGroupLife Class** | Class includes all expected features and follows basic standards                     | 15     |
|                          | Class exists, but is missing features like setters or constructors                   | 8      |
|                          | Class is missing substantial features or is not compiling                         | 0      |
| **LifePolicy Class**     | Class includes all expected features and follows basic standards | 10     |
|                          | Class exists, but is missing features like setters or constructors    | 5      |
|                          | Class is missing substantial features or is not compiling                         | 2      |
| **LifePolicyTests** | Unit tests are included and a variety of scenarios are included to thoroughly validated the required methods | 10     |
|                          | Unit tests are included but are not thorough, or are not working properly    | 5      |
|                          | Unit tests not included in the project	                        | 0      |
| **Total**                |                                                                                      | 35     |
