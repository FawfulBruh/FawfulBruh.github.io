package org.harrisgrouplife;
import java.util.Scanner;
import org.harrisgrouplife.policies.LifePolicy;
/*
Harris Life Insurance - Lilith Smith
 Uses user input to create a Life Insurance policy custom to the user.
 Info is neatly stored & constructed in class LifePolicy's fields
 Life insurance premium costs are calculated based on age, state residency, and retirement status
 When finished, prints policy information along with premium cost into the console.

 Finished 1/10/2026, for IHCC Java I
 */

public class HarrisGroupLife {
  public static void main(String[] args) {
    LifePolicy userPolicy = inputData();
    double premiumCost = userPolicy.calcPremium(userPolicy);
    userPolicy.printPolicy(userPolicy, premiumCost);
  }
  /* My input method returns the inputted data as a constructed
    LifePolicy variable instead of having to rely on a list or array!
    How neat :)
   */
  public static LifePolicy inputData(){
      Scanner userInput = new Scanner(System.in);
      System.out.println("\nPlease enter the name of the policy holder: ");
      String policyHolderName = userInput.nextLine();
      System.out.println("Please enter the birth year of the policy holder: ");
      int birthYear = userInput.nextInt();
      System.out.println("Please enter the current year: ");
      int currentYear = userInput.nextInt();
      System.out.println("Is the policy holder a resident of the state? Enter True or False: ");
      boolean residencyStatus = userInput.nextBoolean();

      /* Ok, I learned something strange about Scanner.
      Apparently, when you use a nextDouble, nextInt, or nextBool instead of nextLine
      The program (for some reason) doesn't remove the extra \n, so when you switch back to nextLine()
      After using a nextInt/Double/Boolean, it instantly returns an empty line. So instead you have to
      ""flush"" the \n with an extra nextLine() before prompting user input for a String.
      Cool I guess (¬_¬)
       */
      userInput.nextLine();

      System.out.println("Is the policy holder currently retired? Enter Y/N: ");
      char retirementChar = (userInput.nextLine()).charAt(0);
      /* This char still works if they type "yes" or "no" because it retrieves
          the first character entered (so "yes" would just return 'y')
       */
      return new LifePolicy(policyHolderName, birthYear, currentYear, residencyStatus, retirementChar);
  }
}
