package org.harrisgrouplife.policies;

public class LifePolicy {
    /* These are the fields I'm going to use for my class constructor!
   They contain every piece of data we need to receive from the user.
    */
    public String policyHolderName;
    public int birthYear;
    public int currentYear;
    public boolean residencyStatus;
    public char retirementChar;

    public LifePolicy(String policyHolderName, int birthYear, int currentYear, boolean residencyStatus, char retirementChar) {
        this.policyHolderName = policyHolderName;
        this.birthYear = birthYear;
        this.currentYear = currentYear;
        this.residencyStatus = residencyStatus;
        this.retirementChar = retirementChar;
    }
    public LifePolicy() {
        /* Default Constructor */
        this.policyHolderName = "Jane Doe";
        this.birthYear = 1989;
        this.currentYear = 2026;
        this.residencyStatus = true;
        this.retirementChar = 'N';
    }
    /* This is the actual class constructor, it uses the fields from the class
     LifePolicy and shares it's name with two key differences, it accepts parameters
     and doesn't use the class keyword

     WHICH by the way is super evil. Like, I cannot tell you how many times I've broken everything
     by declaring a class constructor as a class on accident. >:/
     */
    public double calcPremium(LifePolicy clientPolicy) {
        double premiumCost;
        int clientAge = clientPolicy.currentYear - clientPolicy.birthYear;
        int clientDecades = clientAge / 10;
        /* To calculate decade, we can use clientAge / 10, and we don't have to worry about
        decimals because we're dividing two integers together (the decimal gets left out)
         */
        final double RETIRED_RATE = 7.5;
        final int STATE_RATE = 20;
        final double OUT_OF_STATE_RATE = 22.5;
        /* Need to set some labeled constants for rate, less efficient, but
        it prevents us from having any "magic numbers" that non-coders would have no clue
        what they mean.
        */
        if (clientPolicy.retirementChar == 'Y') {
            premiumCost = clientAge * RETIRED_RATE;
        } else {
            if (clientPolicy.residencyStatus) {
                premiumCost = (clientDecades + 15) * STATE_RATE;
            } else {
                premiumCost = (clientDecades + 15) * OUT_OF_STATE_RATE;
            }
        }
        return premiumCost;
    }
        /* Three conditionals to calculate retirement policy cost
        I REALLY wanted to use a switch:case instead of if:else
        but with only 3 options it's just impractical :,(
     */
        public void printPolicy(LifePolicy clientPolicy, double premiumCost) {
            System.out.println("Current Year: " + clientPolicy.currentYear);
            System.out.println("Age: " + (clientPolicy.currentYear - clientPolicy.birthYear));
            if(clientPolicy.residencyStatus) {
                System.out.println("Residency: In-State");
            } else {
                System.out.println("Residency: Out-Of-State");
            }
            if(clientPolicy.retirementChar == 'Y') {
                System.out.println("Retirement-Status: Retiree");
            } else {
                System.out.println("Retirement-Status: Not Retired");
            }
            System.out.printf("Premium Cost: $%.2f%n", premiumCost);
        }

}
