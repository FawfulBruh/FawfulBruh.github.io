package org.harrisgrouplife.policies;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LifePolicyTests {
    @Test
    void testCalculateDefaultPremiumCost() {
        LifePolicy defaultPolicy = new LifePolicy();
        /* Tests to see if calc generates the right input for default policy.
            Jane Doe's age: 37
           Not Retired: Calculated by 3 (decades) + 15
           State Resident Rate is * 20
           Predicted Result: $360
         */
        assertEquals(360,defaultPolicy.calcPremium(defaultPolicy));
    }
    @Test
    void testInStateRate_VsOutOfStateRate() {
        /* Tests to make sure In-State and Out-Of-State Conditionals
            Affect the final cost of the premium, checks if the
            Out of State & State are equal with identical fields
            (other than state residency)
         */
        String policyHolderName = "John Doe";
        int birthYear = 1986;
        int currentYear = 2026;
        boolean residencyStatus = true;
        char retirementChar = 'N';
        LifePolicy inStatePolicy = new LifePolicy(policyHolderName, birthYear, currentYear, residencyStatus, retirementChar);
        policyHolderName = "Jean Doe";
        residencyStatus = false;
        LifePolicy outOfStatePolicy = new LifePolicy(policyHolderName, birthYear, currentYear, residencyStatus, retirementChar);
        assertNotEquals(outOfStatePolicy.calcPremium(outOfStatePolicy), inStatePolicy.calcPremium(inStatePolicy), 0.0);
    }
    @Test
    void testCalcTruncates_Decades(){
        /* Tests to see if Calc sucessfully truncates decades
           (That is, divides without keeping any decimals)
           Calculates to see if there is an exact 22.50 difference
           between a 39 yr old's policy and a 40 yr old's policy
           Out of state
         */
        String policyHolderName = "Jane Doe";
        int birthYear = 1987;
        int currentYear = 2026;
        boolean residencyStatus = false;
        char retirementChar = 'N';
        LifePolicy thirtyNinePolicy = new LifePolicy(policyHolderName, birthYear, currentYear, residencyStatus, retirementChar);
        birthYear = 1986;
        policyHolderName = "Juan Doe";
        LifePolicy fortyPolicy = new LifePolicy(policyHolderName, birthYear, currentYear, residencyStatus, retirementChar);
        assertNotEquals(fortyPolicy.calcPremium(fortyPolicy), thirtyNinePolicy.calcPremium(thirtyNinePolicy), 0.0);
    }
    /* All three tests passed! Huzzah!!!! */
}
