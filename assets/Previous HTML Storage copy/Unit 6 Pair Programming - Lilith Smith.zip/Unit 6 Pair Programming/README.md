# Unit 6 Pair Programing 

Review the provided project file and fix accessibility problems.
All programmers need to turn in this assigment. 

## Refactor

Refactor the HTML structure to ensure proper heading levels H1, H2, etc. 
Update the page to use semantic elements like nav, main, section, etc.
Add alt text to images.

## Styling

Spend time to make the website look modern using CSS.
Add a favicon. 


## Color Contrast 

Check and fix any color contrast issues between text and background colors while still having a colorful site. 
Optional: [CSS custom properties](https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties) 

## Testing

Test the page with a web browsers accessibility checker.
Document any changes made and explain why they improve accessibility with CSS and HTML comments. 
