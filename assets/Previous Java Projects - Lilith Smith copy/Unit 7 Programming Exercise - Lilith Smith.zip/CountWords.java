import java.util.Scanner;
import java.util.regex.*;

void main() {
    /* Lilith Smith - Chapter 7 Practice Problem 5
    * Pretty simple program, counts the amount of words
    * In a string inputted by the user.
    * Not too difficult to program, but
    * RegEx can be confusing with some of the metacharacters
    * Thankfully we get to use the simplest form of regex with .split()
    *
    * 1/26/2026
    */
    Scanner userInput = new Scanner(System.in);
    System.out.print("Enter a line of text: ");
    String userLine = userInput.nextLine();
    String[] wordArray = userLine.split("[,.!? ]+");
    System.out.println("This line of text contains " + wordArray.length + " words.");
}