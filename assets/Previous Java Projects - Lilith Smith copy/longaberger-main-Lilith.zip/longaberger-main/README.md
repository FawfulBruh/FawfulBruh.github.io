# Longaberger Project Instructions

Follow the general project instructions here to remember how to fork, clone and submit the assignment:  https://github.com/IHCCJava/docs/tree/main/general-project-instructions

See the project directions for part one, two and three here. Remember that each part is done one at a time and graded each week.

# Longaberger Project Part 1
This program will ask for order type, basket specifications, customer type and customer information. It will calculate the total cost which includes sales tax. Output will be displayed on the console.

## The Longaberger class should contain the following

1. Comments should be at the top of this and all programs. Should have a description of the program’s purpose, your name and date. Also place additional comments on lines to clarify what you are doing if needed.
2. Use descriptive names for variables.
3. Use the Scanner or JOptionPane classes for input and/or display.
4. Request the order type from the user. Order type of (S)tandard should use the default constructor. Order type of (C)ustom should request user input for basket type, accessory type, state and customer type
5. All invalid entries should be assigned the default values given for the default constructor
6. Place entered data into a Basket object, based on the order type
7. Call the calculate method in your BasketType object to get the total
8. After calculations, display all input and calculated data in a receipt format with the current date

## The BasketBuild class should contain the following

1. Create a class called BasketBuild.java inside src/main/java/com.longaberger
2. Use private instance variables for input and calculated values.
3. Create getters and setters for the basket type, accessory type, customer type and state
4. Write a default constructor that sets the following values:
    - char Basket Type – U
    - String Accessory Type – A4
    - int Customer Type – 1
    - String State - IA
5. Write a parameterized constructor that takes all the values for basket type, accessory type, customer type and state
6. Write an instance method to calculate the basket amount, subtotal, discount, sales tax and total bill
    - Basket Amount = Basket Cost + Accessory Cost
    - Discount = Basket Amount * Customer Discount Rate
    - Subtotal = Basket Amount – Discount
    - Tax = Subtotal * Tax Rate
    - Total Cost = Subtotal + Tax
        - Dealers DO NOT pay sales tax.
7. Write an instance method to return a formatted string for the receipt

## The BasketBuildTests class should contain the following

1. Under the src directory, create a test/java directory
2. In the test/java folder create the com.longaberger package
3. Inside the test/java/com.longaberger create a class called BasketBuildTests.java
4. Write at least three unit tests to test the calculation method inside BasketBuild
  - Test scenarios should include variations in basket type, accessories, type of customer, etc

## Data for calculations

You'll need the following information to take your inputs and run your calculations.

| Basket Type    | Basket Cost | 
|----------------|-------------|
| C = Cracker    | $15.00      |
| W = Wildflower | $53.25      |
| K = Key        | $23.15      |
| M = Magazine   | $34.20      |
| U = Umbrella   | $112.77     |

| Accessory      | Accessory Cost |
|----------------|----------------|
| A1 = Protector | $4.75          |
| A2 = Liner     | $8.00          | 
| A3 = Combo     | $10.55         |
| A4 = None      | $0.00          |

| State | State Tax Rate |
|-------|----------------|
| IA    | 6%             |
| IL    | 6.25%          |
| MO    | 4.225%         |

| Customer Type | Customer Discount |
|---------------|-------------------|
| 1             | Dealer 50%        |
| 2             | Walk In 0%        |
| 3             | Bus 10%           |

## Rubric

This project is graded on functionality (does it compile, can the user create a basket and get the correct cost). It is also graded on features added in the instructions, like including the correct methods, constructors, data conversions, and tests.

|Topic| Task| Points|
|-----|-----|------|
|**Longaberger class**| Longaberger class includes a logic branch for Standard vs Custom order, input methods, creates a BasketBuild object, and calls instance methods on the object to display proper values | 12|
| | Longaberger class includes only some of the required features and/or features are not working | 5|
| |  Longaberger class does not compile | 0|
|**BasketBuild class** | BasketBuild class includes both constructors, getters/setters, calculation and output methods | 12 |
|| BasketBuild class missing some of the required features and/or features are not working | 5|
|| BasketBuild class does not compile | 0|
|**Calculations** | Calculation method is inside the BasketBuild class. Calculations take into account all the variations of cost based on user input, and outputs the correct cost | 11 |
|| Calculation method is included, but is in the wrong class and/or missing code to produce correct calculations | 5|
|| Calculation method is not implemented | 0|
| **Total** | | 35|

# Longaberger Project Part 2 - Validations
This is an update to your Longaberger project that will add validations to all of the inputs and error handling to all your parse methods.

For an example of input validations, if the user tries to select "X" as the basket type, the program should prompt that X is not one of the accepted values for basket type, and prompt for the basket type again. This will require if/else or switch statements, and loops. You will do this for ALL inputs.

## Longberger class updates
1. Validate all user input (Order Type, Basket Type, Accessory Type, State, and Customer Type)
2. Create a loop for each user input validation requiring the user to input valid data. Display an
error message each time invalid data is entered.
3. Every parse method you use should be wrapped in a try/catch statement for error handling.

## BasketBuild class has no updates this time

## Rubric

This project is graded on features and functionality added for this revision.

|Topic| Task| Points|
|-----|-----|------|
|**Input Validations**| All user inputs are validated for correct values. If an incorrect value is provided, an error is displayed and the program asks for the input again. | 15|
| | Some user inputs are validated, but not all and/or not using looping structure to reprompt the user | 8|
| |  User inputs are not being validated | 0|
|**Error Handling** | All parse methods are wrapped in a try/catch statement to catch any potentional runtime errors and display an error to the user | 15 |
|| Some parse methods have try/catch statements, but not all and/or try/catch was attempted but not working all the way | 8|
|| Try/catch error handling was not used, or used incorrectly | 0|
| **Total** | | 30|

# Longaberger Project Part 3 - Arrays
This is the final update to your longaberger project that will add arrays to store correct data for input validations and calculations.

## Longberger class updates
1. Add a loop to the main method that asks the user if they have another basket to process (Y/N).
2. Create Hard-Coded Arrays for the following information.
    - Basket Type
    - Accessory Code
3. Validate user input for the Basket Type using the hard-coded array
4. Validate user input for the Accessory Code using the hard-coded array

## BasketBuild class updates

1. Create Hard-Coded Arrays for the following information:
    - Literal values are the display values to the user, whereas type and code are the values we use internally. Example, "C" is the Basket Type, and "Cracker" is the Basket Literal
    - Basket Type
    - Basket Literal
    - Basket Cost
    - Accessory Code
    - Accessory Literal
    - Accessory Cost
    - Customer Type Literal
    - Discount Percentage
2. Search the basket type array for a match to the user input to find the array index for the basket type. Use this array index to access the basket literal and the basket cost arrays.
3. Search the accessory code array for a match to the user input to find the array index for the accessory code. Use this array index to access the accessory literal and accessory cost arrays.
4. Use the customer type as the array index to access the customer type literal and discount percentage arrays. (Remember arrays start with 0! Adjust accordingly)
5. Calculation methods should use the cost array values.
6. Display method should use the literal array values.

## Rubric

This project is graded on features and functionality added for this revision.

|Topic| Task| Points|
|-----|-----|------|
|**Hard-coded arrays Longaberger class** | Hard-coded arrays added for Basket Type and Accessory Code inside the Longaberger class| 10 |
|| Only one array was added and/or arrays not setup correctly | 5|
|| Basket Type and Accessory Code arrays missing inside Longaberger class | 0|
|**Input is validated against arrays**| Basket type and accessory code inputs are now validated against the values inside the hard-coded arrays | 10|
| | Only one input is validated against values in the arrays and/or the validation is not reading from the array correctly | 5|
| |  Arrays are not being used for basket type and accessory code validations | 0|
|**Hard-coded arrays BasketBuild class** | All eight hard-coded arrays are created in the BasketBuild class| 10 |
|| Some arrays are missing inside BasketBuild and/or arrays are not setup correctly | 5|
|| Arrays are missing from BasketBuild class | 0|
|**Array usage** | Arrays inside the BasketBuild class are being used correctly to determine cost for calculations, and literal values for display using the indexes | 10 |
|| Some arrays are being utilized for either calculations or displaying and/or the arrays are not being utilized correctly | 5|
|| Arrays are not utilized to lookup values to calculate costs or display literals | 0|
| **Total** | | 40|



