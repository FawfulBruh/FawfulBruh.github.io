package com.longaberger;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BasketBuildTests {
    @Test
    //Test for Default values being correct in class constructor and calc.
    public void test_defaultConstructorValuesCalc(){
        BasketBuild testBasket = new BasketBuild();
        assertEquals('U',testBasket.basketType);
        assertEquals("A4",testBasket.accessoryType);
        assertEquals(1,testBasket.customerType);
        assertEquals("IA",testBasket.state);
        double[] testArray = testBasket.calcBasketBill(testBasket);
        assertEquals(112.77,testArray[0]);
        assertEquals(56.385,testArray[1]);
        assertEquals(56.385,testArray[2]);
        assertEquals(0,testArray[3]);
        assertEquals(56.385,testArray[4]);

    }
    @Test
    // Simple Test, makes sure there is a difference in calc results param. constructor and default constructor
    public void test_ParametersAcceptedInBasketBuilderCalc(){
        BasketBuild testBasket = new BasketBuild();
        BasketBuild userExampleBasket = new BasketBuild('K',"A2",3,"MO");
        double[] testPriceArray = testBasket.calcBasketBill(testBasket);
        double[] userExampleArray = userExampleBasket.calcBasketBill(userExampleBasket);
        assertNotEquals(testPriceArray[0],userExampleArray[0],0);
        assertNotEquals(testPriceArray[1],userExampleArray[1],0);
        assertNotEquals(testPriceArray[2],userExampleArray[2],0);
        assertNotEquals(testPriceArray[3],userExampleArray[3],0);
        assertNotEquals(testPriceArray[4],userExampleArray[4],0);
    }
    @Test
    // Tests in the case of invalid user data, that user information will be overwritten with default.
    public void test_CalcDefaultsWithInvalidData(){
        BasketBuild testBasket = new BasketBuild();
        BasketBuild userExampleBasket = new BasketBuild('Z',"B9",9,"HH");
        double[] testPriceArray = testBasket.calcBasketBill(userExampleBasket);
        double[] userExampleArray =  userExampleBasket.calcBasketBill(userExampleBasket);
        assertEquals(testPriceArray[0],userExampleArray[0],0);
        assertEquals(testPriceArray[1],userExampleArray[1],0);
        assertEquals(testPriceArray[2],userExampleArray[2],0);
        assertEquals(testPriceArray[3],userExampleArray[3],0);
        assertEquals(testPriceArray[4],userExampleArray[4],0);
    }
}

