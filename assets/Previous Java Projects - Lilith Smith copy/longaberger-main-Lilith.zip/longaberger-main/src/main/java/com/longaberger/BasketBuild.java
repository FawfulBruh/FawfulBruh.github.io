package com.longaberger;
/* Class Constructors & Methods for Constructed Objects!
    I got the fields' names from the default
    constructor in the README.

    For Longaberger, constructs BasketBuild
    objects, calculates orders, and prints
    output of calc methods.

 */
import javax.swing.*;

public class BasketBuild {
    char basketType;
    String accessoryType;
    int customerType;
    String state;

    // Default Constructor
    public BasketBuild() {
        this.basketType = 'U';
        this.accessoryType = "A4";
        this.customerType = 1;
        this.state = "IA";
    }

    // Parameterized Constructor
    // (^ that's a mouthful)
    public BasketBuild(char basketType, String accessoryType, int customerType, String state) {
        this.basketType = basketType;
        this.accessoryType = accessoryType;
        this.customerType = customerType;
        this.state = state;
    }
    /* Version 3: Hard Coded arrays
    I initially wanted to reference the arrays in the switch statements to simplify the
    validation process, but I figured out that switch statements need constants, and arrays apparently,
    can't be constant because they are assigned at runtime, not compilation
    (final does not work w/ switch either, same reason.)
     */
    // --------- V3 Hard-coded Arrays ---------

    // Hard-Coded Valid Field Arrays
    final char[] BasketTypesList = {'C','W','K','M','U'};
    final String[] AccessoryCodeList = {"A1","A2","A3","A4"};
    final int[] CustomerTypesList = {1,2,3};
    final String[] StatesList = {"IA","IL","MO"};

    // Hard-Coded Cost Arrays
    final double[] typeCostList = { 15, 53.25, 23.15, 34.20, 112.77 };
    final double[] accessoryCostList = { 4.75, 8, 10.55, 0 };
    final double[] customerDiscountPercentList = { 0.5, 0, 0.1 };
    final double[] stateTaxPercentageList = { 0.06, 0.0625, 0.04225 };

    //  Hard-Coded Literal Arrays
    final String[] basketLiterals = { "Crackers", "Wildflower", "Key", "Magazine", "Umbrella"};
    final String[] accessoryLiterals = { "Protector", "Liner", "Combo", "No Accessory"};
    final String[] customerLiteral = { "Dealer", "Walk-In", "Bus" };
    final String[] stateLiteral = { "Iowa", "Illinois", "Missouri" };


    public double[] calcBasketBill(BasketBuild userBasket) {
        // For the indexes that match with the hard-coded arrays and user-input, declared here
        // So they can stay in scope
        //   ALSO: I need to initialize these variables so that just in case something went wrong in the validation,
        //   I can give these indexes their default values so we don't crash the program
        int basketIndex = 4;
        int accessoryIndex = 3;
        int customerIndex = 0;
        int stateIndex = 0;
        // Version 3: Replaced Switch statements with a searching for-loop, more compact, and less magic numbers!
        // We can skip this for-loop if we know they are already a dealer, and set the rate to 0.
        for (int index = 0; index < BasketTypesList.length; index++){
            if(userBasket.basketType == BasketTypesList[index]){
                basketIndex = index;
                break;
            }
        }

        for (int index = 0; index < AccessoryCodeList.length; index++){
            if((userBasket.accessoryType).equals(AccessoryCodeList[index])){
                accessoryIndex = index;
                break;
            }
        }

        for (int index = 0; index < CustomerTypesList.length; index++){
            if(userBasket.customerType == CustomerTypesList[index]){
                customerIndex = index;
                break;
            }
        }

        for (int index = 0; index < StatesList.length; index++){
            if((userBasket.state).equals(StatesList[index])){
                stateIndex = index;
                break;
            }
        }
        // Final calculations and sales variables to return
        double basketCost = typeCostList[basketIndex] + accessoryCostList[accessoryIndex];
        double costDiscounted = basketCost * customerDiscountPercentList[customerIndex];
        double subtotal = basketCost - costDiscounted;
        double taxTotal;
        if (CustomerTypesList[customerIndex] != 1) {
            taxTotal = basketCost * stateTaxPercentageList[stateIndex];
        } else {
            taxTotal = 0;
        }
        double finalCost = subtotal + taxTotal;
        // Assign String Literals
        String basketName = basketLiterals[basketIndex];
        String accessoryName = accessoryLiterals[accessoryIndex];
        String customerName = customerLiteral[customerIndex];
        String stateName = stateLiteral[stateIndex];
        // Apparently, discounts are applied BEFORE sales tax. Had to look that one up.
        //
        String[] literalArray = { basketName, accessoryName, customerName, stateName };
        double[] costArray = { basketCost, costDiscounted, subtotal, taxTotal, finalCost };
        outputCalc(costArray, literalArray);
        return costArray;
        /* Also, my function used to be void, passing directly into outputCalc()
         But I wanted to rectify that, so I can run individual tests on calc
         Because it's really hard to retrieve those values from a JFrame
         */
    }

    public void outputCalc(double[] costArray, String[] literalArray) {
        // Wanted to try and do it fancy with JFrame again.
        // Much easier this time now that I know what a class constructor is!
        JFrame billFrame = new JFrame();
        // V3: Added a NEW Column to JTable, "Type", which prints the literal values of the categories.
        String[] columnNames = {"Category","Type","Cost"};
        String[][] contentArray = {
                {"Basket Price", (literalArray[0] + " with " + literalArray[1]),String.format("$ %.2f", costArray[0])},
                {"Discount", literalArray[2],String.format("$ -%.2f", costArray[1])},
                {"Subtotal", "",String.format("$ %.2f", costArray[2])},
                {"Sales Tax", literalArray[3],String.format("$ %.2f", costArray[3])},
                {"Total", "",String.format("$ %.2f", costArray[4])}
        };
        JTable userItemizedBill = new JTable(contentArray, columnNames);
        JScrollPane billScrollPane = new JScrollPane(userItemizedBill);
        billFrame.add(billScrollPane);
        billFrame.setBounds(10,10,500,150);
        billFrame.setVisible(true);
    }
}