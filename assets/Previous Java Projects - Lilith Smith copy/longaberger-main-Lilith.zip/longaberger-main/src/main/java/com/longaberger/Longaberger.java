package com.longaberger;
import java.util.InputMismatchException;
import java.util.Scanner;
/* Longaberger Project - Lilith Smith
   Prompts the user to enter specific data for a BasketBuild class object,
   Which constructs a parameterized BasketBuild object.

   User's BasketBuild object is then passed to be calculated, where prices
   are assigned based on BasketBuild's fields.

   Then, outputs an itemized list of expenses through a JFrame
   JTable.

   Version 2: Added Try/Catch Exceptions to validate user input!

   Version 3: Added a loop in main, transferred individual objects into an array before being displayed,
        and updated validation to use for-loops & hard-coded arrays instead of switches
 */

public class Longaberger {
    public static void main(String[] args) {
            BasketBuild userBasket = userInputBasket();
            userBasket.calcBasketBill(userBasket);
            if(promptLoop()){
                main(new String[]{""});
            } else {
                System.exit(0);
            }
        // V3: Output method is now inside calcBasketBill, and looped main
        // Depending on user input, will loop indefinitely.
    }
    public static boolean promptLoop() {
        Scanner promptUser = new Scanner(System.in);
        System.out.println("\nWould you like to calculate another basket? Enter Y/N:");
        String userResponse = promptUser.nextLine();
        if (userResponse.equals("Y")) {
            return true;
        } else {
            promptUser.close();
            return false;
        }
    }
    public static BasketBuild userInputBasket() {
        Scanner userInputScanner = new Scanner(System.in);
        // Version 3: My hard-coded final arrays for validation
        final char[] BasketTypesList = {'C','W','K','M','U'};
        final String[] AccessoryCodeList = {"A1","A2","A3","A4"};
        final int[] CustomerTypesList = {1,2,3};
        final String[] StatesList = {"IA","IL","MO"};

        System.out.println("Please enter the type of basket as a char: ");
        char inputBasket = userInputScanner.next().charAt(0);

        /* Version 3 edit: Instead of using a lengthy switch statement, like in versions 1 and 2,
         I replaced my validation try/execpt blocks with loops
         The loops start outside with the boolean validInput, which starts as false
         These loops reference the hard-coded arrays and search every "valid" response available
         If one is found, validInput will be set to true, the loop will break early, and no exceptions will occur.
         If none are found, validInput will still be false, and throw an error with a conditional outside the loop.
        */
        try {
            boolean validInput = false;
            for (int temp = 0; temp < BasketTypesList.length; temp++) {
                if (BasketTypesList[temp] == inputBasket) {
                    validInput = true;
                    break;
                }
            }
            if (validInput != true) {
                throw new InputMismatchException();
            }

        } catch (Exception InputMismatchException) {
            throw new RuntimeException("Invalid UserInput for basketChar: Not a valid char!");
        }
        // It did the thing again... Have to flush this \n
        userInputScanner.nextLine();
        System.out.println("Please enter the type of accessory as an A#: ");
        String inputAccessory = userInputScanner.nextLine();
        // Same try/except block as before, but I changed the equivalence operator to use
        // The String.equals() function instead because Strings just be like that
        try {
            boolean validInput = false;
            for (int temp = 0; temp < AccessoryCodeList.length; temp++) {
                if (AccessoryCodeList[temp].equals(inputAccessory)) {
                    validInput = true;
                    break;
                }
            }
            if (validInput != true) {
                throw new InputMismatchException();
            }
        } catch (Exception InputMismatchException) {
            throw new RuntimeException("Invalid user input for accessoryType: String is not a valid A# value.");
        }
        System.out.println("Please enter the customer type as an integer: ");
        String inputCustomerLine = userInputScanner.nextLine();
        try {
           Integer.parseInt(inputCustomerLine);
        } catch (Exception InputMismatchException) {
            throw new RuntimeException("Invalid user input for customerType: Not an integer!");
        }
        int inputCustomer = Integer.parseInt(inputCustomerLine);
        // Two exceptions here, one to determine if the user entered an integer
        // And the second to determine if it's a valid integer
        try {
            boolean validInput = false;
            for (int temp = 0; temp < CustomerTypesList.length; temp++) {
                if (CustomerTypesList[temp] == inputCustomer) {
                    validInput = true;
                    break;
                }
            }
            if (validInput != true) {
                throw new InputMismatchException();
            }
        } catch (Exception InputMismatchException) {
            throw new RuntimeException("Invalid user input for customerType: Invalid Integer!");
        }
        System.out.println("Please enter the abbreviated state name: ");
        String inputState = userInputScanner.nextLine();
        // I know this wasn't technically required to validate every line, but I wanted to do it anyway :)
        // Don't forget the .equals() instead of "=="!
        try {
            boolean validInput = false;
            for (int temp = 0; temp < StatesList.length; temp++) {
                if (StatesList[temp].equals(inputState)) {
                    validInput = true;
                    break;
                }
            }
            if (validInput != true) {
                throw new InputMismatchException();
            }
        } catch (Exception InputMismatchException) {
            throw new RuntimeException("Invalid user input for state: String is not a valid state!");
        }
        System.out.println("Data Received...");
        return new BasketBuild(inputBasket, inputAccessory, inputCustomer, inputState);
    }
}