# Harvey Home Repair

You will create a program for Harvey's Home Repair service to take and track estimates.
You will code in two separate classes. One class called HarveyHomeRepair.java that will have your main
method and be the main control for the program, and a separate class called Estimate that you can
make estimate objects from.

Check the comments in these files to make sure your methods have the correct names and return types. 
This is important to have passing tests at the end of this program.

## Project Instructions

[Follow these general instructions to fork, clone and submit the project](https://ihccjava.github.io/docs/general-project-instructions/)

- Comments should be at the top of all programs. Should have a
  description of the program’s purpose, your name and date. Also place
  additional comments on lines to clarify what you are doing if needed.
- Use descriptive names for variables.

### The client/control program (HarveyHomeRepair.java) should contain the following:

- Create methods to accept user input for job name, cost of materials, labor hours, and travel
  hours. (Check comments in the HarveyHomeRepair class for correct method names).
- Each input method should have it's own Scanner declared inside each method (the tests are expecting this). 
- In the main method:
  1. Call the input methods and save input to local variables.
  2. Place entered data into an estimate object using the parameterized
  constructor
  3. After input, call the calculate total estimate cost method on your estimate object
  4. After calculations, call your output method on your estimate object to display the job name, cost of materials, labor hours, travel
  hours, labor cost, travel cost, total estimate cost.

### The instantiable class (Estimate.java) should contain the following:
- private instance variable constants for the labor rate and the travel rate.
  - Labor rate is $55.00 per hour
  - Travel costs are $14.77 per hour
- private instance variables called jobName, costOfMaterials, laborHours, travelHours.
- getters/setters for all instance variables with standard naming convention
- You will create four unique constructors. This is to practice making constructors. For the project, you'll only end up calling one of them.
  - default constructor that accepts no parameters and sets your instance variables to these default values:
    - job name = “Sample”
    - cost of materials = 500.00
    - labor hours = 1
    - travel hours = 1
  - parameterized constructor (accepts job name, cost of materials, labor hours
    and travel hours as parameters and sets the instance variables to the values passed in)
  - parameterized constructor (accepts job name and cost of materials as parameters and sets the instance variables to the values passed in)
    - The instance variables not passed in are set to default values:
    - labor hours = 1
    - travel hours = 1
  - parameterized constructor (accepts job name, cost of materials and labor hours as parameters and sets the instance variables to the values passed in)
    - The instance variables not passed in are set to default values:
    - travel hours = 1
- Create an instance method that accepts no parameters and returns a double of the calculated labor cost
  - Labor cost is labor rate * labor hours
- Create an instance method that accepts no parameters and returns a double of the calculated travel cost
  - Travel cost is the travel rate * travel hours
- Create an instance method that accepts no parameters and returns a double of the total estimate cost
  - Total estimate cost is sum of material, labor costs, and travel costs.
  - Inside this method, call the calculate labor cost and calculate travel cost to retrieve those values and add them to the total estimate cost.
- Create an instance method that accepts no parameters and returns a String with formatted output
  - The exact format is up to use (I suggest using DecimalFormatter to help with dollar amounts)
  - Must include all details from an estimate:
    - job name, cost of materials, labor hours, travel hours, labor cost, travel cost, total estimate cost.

### Rubric

Projects are graded on functionality (does it compile, can the user do what they are supposed to, and do they get the expected results). It is also graded on features added in the instructions, like including the correct methods, constructors, data conversions, and tests.

| Topic                                 | Task                                                                | Points |
|---------------------------------------|---------------------------------------------------------------------|--------|
| **HarveyHomeRepair Class**            | Class uses methods to gather all required input, creates an Estimate object to save information and interact with Estimate methods | 15     |
|                                       | Class gathers inputs, but does not use method and/or does not create Estimate object | 8 |
|                                       | Class is missing significant features and/or does not compile       | 2 |
| **Estimate Class**                    | Class is created following instructions with all variables, methods, and constructors  | 10     |
|                                       | Class contains some, but not all methods/variables, and/or calculations incorrect | 5 |
|                                       | Class is missing significant features and/or does not compile       | 2 |
| **Total**                             |                                                                     | 25     |
