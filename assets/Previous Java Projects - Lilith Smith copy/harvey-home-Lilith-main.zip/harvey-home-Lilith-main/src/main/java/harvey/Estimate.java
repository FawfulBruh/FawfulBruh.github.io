package harvey;
/* Lilith Smith - harvey.Estimate
IHCC Java I - 12/17/2025

Runs calculations for price estimate
Requires data from the user, acquired in main
Then outputs the calculated estimate
 */
public class Estimate {
    /* Define class level variables here */
    private double laborRate = 55;
    private double travelRate = 14.77;
    private String jobName;
    private double materialCost;
    private double laborHours;
    private double travelHours;
    /* Create constructors here */
    public Estimate()
    {
        jobName = "Sample";
        materialCost = 500.00;
        laborHours = 1;
        travelHours = 1;
    }
    public Estimate(String passed_jobName, double passed_materialCost, double passed_laborHours, double passed_travelHours)
    {
        jobName = passed_jobName;
        materialCost = passed_materialCost;
        laborHours = passed_laborHours;
        travelHours = passed_travelHours;
    }
    public Estimate(String passed_jobName, double passed_materialCost)
    {
        jobName = passed_jobName;
        materialCost = passed_materialCost;
        laborHours = 1;
        travelHours = 1;
    }
    public Estimate(String passed_jobName, double passed_materialCost, double passed_laborHours)
    {
        jobName = passed_jobName;
        materialCost = passed_materialCost;
        laborHours = passed_laborHours;
        travelHours = 1;
    }

    /* Getters for private variables */
    public double getLaborRate(){
        return laborRate;
    }
    public double getTravelRate(){
        return travelRate;
    }
    public String getJobName(){
        return jobName;
    }
    public double getCostOfMaterials(){
        return materialCost;
    }
    public double getLaborHours(){
        return laborHours;
    }
    public double getTravelHours(){
        return travelHours;
    }

    /* Setters for private variables */

    public void setLaborRate(double laborRate){
        this.laborRate = laborRate;
    }
    public void setTravelRate(double travelRate){
        this.travelRate = travelRate;
    }
    public void setJobName(String jobName){
        this.jobName = jobName;
    }
    public void setCostOfMaterials(double materialCost){
        this.materialCost = materialCost;
    }
    public void setLaborHours(double laborHours){
        this.laborHours = laborHours;
    }
    public void setTravelHours(double travelHours){
        this.travelHours = travelHours;
    }
    /* Write a method called calculateLaborCost that returns a double of the calculated labor costs */
    public double calculateLaborCost(){
        return laborHours * laborRate;
    }
    /* Write a method called calculateTravelCost that returns a double of the calculated travel costs */
    public double calculateTravelCost(){
        return travelHours * travelRate;
    }
    /* Write a method called calculateTotalEstimateCost that returns a double of the total estimate cost */
    public double calculateTotalEstimateCost(){
        return calculateLaborCost() + calculateTravelCost() + materialCost;
    }
    /* Write a method called output that returns a formatted String of all the estimate details */
    public String output(){
        return String.format("Job Name: %s\n", jobName) +
                String.format("Labor Hours: %,.2f\n", laborHours) +
                String.format("Travel Hours: %,.2f\n", travelHours) +
                String.format("Cost of Materials $%,.2f\n", materialCost) +
                String.format("Cost of Labor: $%,.2f\n", calculateLaborCost()) +
                String.format("Cost of Travel: $%,.2f\n", calculateTravelCost()) +
                String.format("Total Estimate $%,.2f\n", calculateTotalEstimateCost());
    }

}
