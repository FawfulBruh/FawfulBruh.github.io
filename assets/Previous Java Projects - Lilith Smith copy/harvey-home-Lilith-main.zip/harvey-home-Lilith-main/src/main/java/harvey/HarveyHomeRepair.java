package harvey;
import java.util.Scanner;

/* Lilith Smith - harvey.HarveyHomeRepair
IHCC Java I - 12/17/2025

Main class for Harvey Home Repair Project
Uses user input to produce an estimate for a
Hypothetical home repair job

I was confused on constructors for awhile- but
now I'm starting to understand why Java's called an
object based programming language!
Every thing is either static (no object)
or non-static (object)

I just didn't know what static meant until now.
"Wait... It's all objects?"
"Always has been."
 */

public class HarveyHomeRepair {

    public static void main(String[] args) {
        /*Setup any variables you need and call your methods
         * here in the main method */
        String jobName = inputJobName();
        double materialCost = inputCostOfMaterials();
        double laborHours = inputLaborHours();
        double travelHours = inputTravelHours();
        /* Just wanted to add a space so it's easier to read */
        System.out.println("\n");
        /* New Estimate object */
        Estimate newEstimate = new Estimate(jobName, materialCost, laborHours, travelHours);
        System.out.println(newEstimate.output());

    }
    /* Write a method called inputJobName that prompts the user to enter
    *  a job name, then returns a String with the job name.*/
    public static String inputJobName() {
        Scanner userNameInput = new Scanner(System.in);
        System.out.print("Enter the name of your job: ");
        return userNameInput.nextLine();
    }
    public static double inputCostOfMaterials() {
        Scanner userCostInput = new Scanner(System.in);
        System.out.print("Enter the cost of materials as a double: ");
        return userCostInput.nextDouble();
    }
    /* Write a method called inputCostOfMaterials that prompts the user to enter
     * the cost of materials, then returns a double with the cost of materials.*/
    public static double inputLaborHours() {
        Scanner userLaborHours = new Scanner(System.in);
        System.out.print("Enter the amount of hours worked as a double: ");
        return userLaborHours.nextDouble();
    }
    /* Write a method called inputLaborHours that prompts the user to enter
     * the amount of labor hours, then returns a double with the labor hours.*/
    public static double inputTravelHours() {
        Scanner userTravelHours = new Scanner(System.in);
        System.out.print("Enter the amount of hours traveled as a double: ");
        return userTravelHours.nextDouble();
    }
    /* Write a method called inputTravelHours that prompts the user to enter
     * the amount of travel hours, then returns a double with the travel hours.*/

}