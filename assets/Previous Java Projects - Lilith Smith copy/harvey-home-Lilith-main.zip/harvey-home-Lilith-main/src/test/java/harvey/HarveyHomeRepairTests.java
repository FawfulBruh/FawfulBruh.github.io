package harvey;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static harvey.TestConstants.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class HarveyHomeRepairTests {

    private void mockScannerInput(String input) {
        ByteArrayInputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
    }


    /* input tests */
    @Test
    public void whenInputJobNameIsString_thenReturnIsValid() {
        mockScannerInput(JOB_NAME);
        assertEquals(JOB_NAME, HarveyHomeRepair.inputJobName());
    }

    @Test
    public void whenInputCostOfMaterialsIsDouble_thenReturnIsValid() {
        mockScannerInput(String.valueOf(COST_OF_MATERIALS));
        assertEquals(COST_OF_MATERIALS, HarveyHomeRepair.inputCostOfMaterials());
    }

    @Test
    public void whenInputCostOfMaterialsIsString_thenThrowsException() {
        assertThrows(RuntimeException.class, () -> {
            ByteArrayInputStream in = new ByteArrayInputStream(JOB_NAME.getBytes());
            System.setIn(in);
            HarveyHomeRepair.inputCostOfMaterials();
        });
    }

    @Test
    public void whenInputLaborHoursIsDouble_thenReturnIsValid() {
        mockScannerInput(String.valueOf(LABOR_HOURS));
        assertEquals(LABOR_HOURS, HarveyHomeRepair.inputLaborHours());
    }

    @Test
    public void whenInputLaborHoursIsString_thenThrowsException() {
        assertThrows(RuntimeException.class, () -> {
            ByteArrayInputStream in = new ByteArrayInputStream(JOB_NAME.getBytes());
            System.setIn(in);
            HarveyHomeRepair.inputLaborHours();
        });
    }

    @Test
    public void whenInputTravelHoursIsDouble_thenReturnIsValid() {
        mockScannerInput(String.valueOf(TRAVEL_HOURS));
        assertEquals(TRAVEL_HOURS, HarveyHomeRepair.inputTravelHours());
    }

    @Test
    public void whenInputTravelHoursIsString_thenThrowsException() {
        assertThrows(RuntimeException.class, () -> {
            ByteArrayInputStream in = new ByteArrayInputStream(JOB_NAME.getBytes());
            System.setIn(in);
            HarveyHomeRepair.inputTravelHours();
        });
    }
}
