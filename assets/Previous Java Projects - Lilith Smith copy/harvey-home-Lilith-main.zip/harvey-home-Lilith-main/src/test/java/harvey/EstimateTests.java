package harvey;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static harvey.TestConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EstimateTests {

    private static Estimate estimate = new Estimate();
    private static Estimate defaultEstimate = new Estimate();

    @BeforeAll
    public static void setUp() {
        estimate.setLaborHours(100);
        estimate.setTravelHours(100);
        estimate.setCostOfMaterials(200);
    }

    /* constructor tests */
    @Test
    public void whenDefaultConstructorIsCalled_thenDefaultValuesAreCorrect() {
        assertEquals("Sample", defaultEstimate.getJobName());
        assertEquals(500, defaultEstimate.getCostOfMaterials());
        assertEquals(1, defaultEstimate.getLaborHours());
        assertEquals(1, defaultEstimate.getTravelHours());
    }

    @Test
    public void whenFirstParameterizedConstructorIsCalled_thenValuesAreCorrect() {
        Estimate estimateParameterizedConstructor = new Estimate(JOB_NAME, COST_OF_MATERIALS, LABOR_HOURS, TRAVEL_HOURS);
        assertEquals(JOB_NAME, estimateParameterizedConstructor.getJobName());
        assertEquals(COST_OF_MATERIALS, estimateParameterizedConstructor.getCostOfMaterials());
        assertEquals(LABOR_HOURS, estimateParameterizedConstructor.getLaborHours());
        assertEquals(TRAVEL_HOURS, estimateParameterizedConstructor.getTravelHours());
    }

    @Test
    public void whenSecondParameterizedConstructorIsCalled_thenValuesAreCorrect() {
        Estimate estimateParameterizedConstructor = new Estimate(JOB_NAME, COST_OF_MATERIALS);
        assertEquals(JOB_NAME, estimateParameterizedConstructor.getJobName());
        assertEquals(COST_OF_MATERIALS, estimateParameterizedConstructor.getCostOfMaterials());
        assertEquals(1, estimateParameterizedConstructor.getLaborHours());
        assertEquals(1, estimateParameterizedConstructor.getTravelHours());
    }

    @Test
    public void whenThirdParameterizedConstructorIsCalled_thenValuesAreCorrect() {
        Estimate estimateParameterizedConstructor = new Estimate(JOB_NAME, COST_OF_MATERIALS, LABOR_HOURS);
        assertEquals(JOB_NAME, estimateParameterizedConstructor.getJobName());
        assertEquals(COST_OF_MATERIALS, estimateParameterizedConstructor.getCostOfMaterials());
        assertEquals(LABOR_HOURS, estimateParameterizedConstructor.getLaborHours());
        assertEquals(1, estimateParameterizedConstructor.getTravelHours());
    }
    /* calculateLaborCost tests */
    @Test
    public void whenEstimateIsDefault_thenCalculatedLaborCostIsCorrect() {
        assertEquals(55, defaultEstimate.calculateLaborCost());
    }

    @Test
    public void whenEstimateIsNonDefault_thenCalculatedLaborCostIsCorrect() {
        assertEquals(5500, estimate.calculateLaborCost());
    }
    /* calculateTravelCost tests */
    @Test
    public void whenEstimateIsDefault_thenCalculatedTravelCostIsCorrect() {
        assertEquals(14.77, defaultEstimate.calculateTravelCost());
    }

    @Test
    public void whenEstimateIsNonDefault_thenCalculatedTravelCostIsCorrect() {
        assertEquals(1477, estimate.calculateTravelCost());
    }

    /* calculateTotalEstimateCost tests */
    @Test
    public void whenEstimateIsDefault_thenCalculateTotalEstimateCostIsCorrect() {
        assertEquals(569.77, defaultEstimate.calculateTotalEstimateCost());
    }

    @Test
    public void whenEstimateIsNonDefault_thenCalculateTotalEstimateCostIsCorrect() {
        assertEquals(7177, estimate.calculateTotalEstimateCost());
    }

    /* output test */

    @Test
    public void whenOutputIsCalled_thenReturnsString() {
        assertTrue(estimate.output() != null);
    }
}
