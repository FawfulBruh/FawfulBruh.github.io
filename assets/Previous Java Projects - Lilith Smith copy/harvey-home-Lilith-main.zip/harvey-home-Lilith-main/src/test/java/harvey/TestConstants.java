package harvey;

public class TestConstants {
    public final static String JOB_NAME = "Fix siding";
    public final static double COST_OF_MATERIALS = 200;
    public final static double LABOR_HOURS = 30;
    public final static double TRAVEL_HOURS = 2;
}
