import java.util.Scanner;
public class evenOrOdd {
    /*   Even or Odd Boolean Return Program
        Unit 5 Practice Problem, IHCC Java
     Asks user for an integer, then passes it to calc.
     Calc will return either true or false, then it prints the result.
      Lilith Smith, 1/11/2026
     */
    static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        System.out.println("Enter an integer to see if it's even or odd: ");
        int inputInt = userInput.nextInt();
        if(calcEven(inputInt)) {
            System.out.println("OK, you're not gunna believe this... it's even.");
        } else {
            System.out.println("I know this sounds crazy... but it's odd.");
        }
    }
    static boolean calcEven(int inputInt) {
        if (inputInt % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }
    /*
     Takes input from an integer parameter, then performs modulus by 2
     to see if there is a remainder. If there is none, it can be cleanly divided
     so it's even, if there is, it means it's odd.

     I remember remainders from Second Grade... I'm getting OLD!!!! T^T
     */

}
