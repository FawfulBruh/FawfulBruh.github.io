package org.example;
public class Main {
    static void main() {
        IO.println("Lilith Smith");
    }
}
