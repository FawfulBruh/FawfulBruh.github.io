package org.example;
import javax.swing.*;
import java.util.Scanner;

// These are both class methods mentioned in the book as useful tools for user input!

public class Main {
    public static void main(String[] args) {
        // final variables because they're named constants
        final double STATE_TAX = 0.04;
        final double COUNTY_TAX = 0.02;
        // Do counties actually have taxes?
        // I thought it was just state and federal
        // ¯\_(ツ)_/¯
        Scanner userInput = new Scanner(System.in);
        System.out.print("Enter the price of the product as a double (press ENTER to submit): ");
        double subtotal = userInput.nextDouble();
        double stateTax = subtotal * STATE_TAX;
        double countyTax = subtotal * COUNTY_TAX;
        double finalPrice = subtotal + stateTax + countyTax;
        // Had to look up how to form a JTable for the output
        // You have to make array with all of your table data
        // And another array for the titles of each column
        JFrame frameTaxTable = new JFrame("Price Tax Table");
        Object[] dataArray = new Object[]{subtotal, stateTax, countyTax, finalPrice};
        Object[][] tableData = new Object[][]{dataArray};
        Object[] columnNames = new Object[]{"Subtotal", "State Tax", "County Tax", "Total Price"};
        JTable finalTable = new JTable(tableData, columnNames);
        // OK so this table sucked to make BUT I need to explain how I did it to show you I actually did it and didn't copy & paste.
        // BASICALLY JTable is a funny new variable type that allows you to make cool
        // VISUAL tables in the GUI with two parameters, one is a 2D array, the other is a regular array
        // ALSO they have to be Object arrays, SPECIFICALLY Object arrays (don't ask me why)
        // and We're not even done yet because after all that we still have to DISPLAY the table!
        JScrollPane paneTaxTable = new JScrollPane(finalTable);
        frameTaxTable.add(paneTaxTable);
        frameTaxTable.pack();
        frameTaxTable.setVisible(true);
        // Then had to go back and add a "frame", which apparently is the base for the pop-up window
        // I also had to place my JTable into a "JScrollPane", turning my blank JFrame into a scrollable window
        // And then FINALLY I used ".pack" to save my changes and set it to become visible.
        // (If this wasn't so obtuse to use I would MAYBE think the window puns are funny)
        // Despite my frustrations with figuring this out it was a lot of fun to challenge myself :)

        // PS: If this is too much explanation (comments, I mean) just let me know and I will tone it down for my next project.
        // I just want to "explain my work" to show you I understand what I'm being taught since I'm not there in person :)
    }
}